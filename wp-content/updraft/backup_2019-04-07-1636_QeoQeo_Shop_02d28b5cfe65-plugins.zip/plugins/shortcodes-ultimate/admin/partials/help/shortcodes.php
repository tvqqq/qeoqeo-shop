<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="http://docs.getshortcodes.com/category/15-getting-started" target="_blank"><strong><?php _e( 'Getting started', 'shortcodes-ultimate' ); ?></strong></a></li>
	<li><a href="http://docs.getshortcodes.com" target="_blank"><?php _e( 'Full documentation', 'shortcodes-ultimate' ); ?></a></li>
	<li><a href="https://getshortcodes.com/support/" target="_blank"><?php _e( 'FAQ & Support', 'shortcodes-ultimate' ); ?></a></li>
</ul>
