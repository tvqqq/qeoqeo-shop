jQuery(function($) {
    $('.has-child').ready(function() {
        $('.has-child').addClass('active');
    });
});