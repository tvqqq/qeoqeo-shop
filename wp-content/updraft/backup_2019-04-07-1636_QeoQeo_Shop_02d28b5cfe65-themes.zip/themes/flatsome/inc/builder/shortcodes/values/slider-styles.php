<?php

return array(
  '' => 'Normal',
  'focus' => 'Focus',
  'container' => 'Container'
)

?>