<?php

return array(
    'xsmall' => array( 'title' => 'XS'),
    'small'   => array( 'title' => 'S'),
    'medium'  => array( 'title' => 'M'),
    'large'  => array( 'title' => 'L'),
    'xlarge'  => array( 'title' => 'XL'),
);
