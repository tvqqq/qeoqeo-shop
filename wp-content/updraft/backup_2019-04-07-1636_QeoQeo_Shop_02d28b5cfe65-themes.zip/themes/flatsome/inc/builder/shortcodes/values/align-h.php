<?php

return array(
    'left' => 'Left',
    'center' => 'Center',
    'right' => 'Right',
);
